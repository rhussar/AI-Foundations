import argparse
import json
import os
import re
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parent
PROMPT_PATH = ROOT / "prompts" / "receipts_extract.md"
DEFAULT_DOCS_DIR = ROOT / "hw1_spoke_and_wrench" / "pdfs"
DEFAULT_OUTPUT_DIR = ROOT / "output"


def load_environment():
    for candidate in [ROOT / ".env", ROOT.parent / ".env"]:
        if candidate.exists():
            load_dotenv(candidate)

    api_key = os.getenv("PORTKEY_API_KEY")
    if not api_key:
        raise RuntimeError("PORTKEY_API_KEY is not set. Add it to the workspace .env file.")

    return api_key


def build_client():
    api_key = load_environment()
    return OpenAI(
        api_key=api_key,
        base_url="https://api.portkey.ai/v1",
        default_headers={
            "x-portkey-api-key": api_key,
            "x-portkey-provider": "openai",
        },
    )


def get_receipt_files(docs_dir: Path):
    receipt_files = sorted(docs_dir.glob("receipt_*.pdf"))
    if not receipt_files:
        raise FileNotFoundError(f"No receipt PDFs found in {docs_dir}")
    return receipt_files


def read_prompt_template():
    if not PROMPT_PATH.exists():
        raise FileNotFoundError(f"Prompt template not found: {PROMPT_PATH}")
    return PROMPT_PATH.read_text(encoding="utf-8")


def clean_extracted_json(raw_text: str):
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        match = re.search(r"```(?:json)?\s*(.*?)\s*```", cleaned, re.S)
        if match:
            cleaned = match.group(1).strip()
    return cleaned


def normalize_row(row: dict, source_file: str):
    if not isinstance(row, dict):
        raise ValueError(f"Expected a JSON object, got: {type(row).__name__}")

    row["source_file"] = row.get("source_file") or source_file
    row.setdefault("fields_not_found", [])

    required_fields = [
        "Vendor",
        "Date",
        "Description",
        "Amount_USD",
        "Category",
        "source_file",
    ]

    missing = []
    for field in required_fields:
        if row.get(field) is None:
            missing.append(field)
    if missing:
        for field in missing:
            if field not in row["fields_not_found"]:
                row["fields_not_found"].append(field)

    return row


def extract_pdf_text(file_path: Path) -> str:
    try:
        reader = PdfReader(str(file_path))
        pages = [page.extract_text() or "" for page in reader.pages]
        text = "\n\n".join(pages).strip()
        if not text:
            raise ValueError(f"No readable text found in {file_path.name}")
        return text
    except Exception as exc:
        raise RuntimeError(f"Failed to extract text from {file_path.name}: {exc}") from exc


def extract_receipt_row(client: OpenAI, file_path: Path, prompt_text: str):
    extracted_text = extract_pdf_text(file_path)

    response = client.responses.create(
        model="gpt-5.6",
        input=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_text",
                        "text": (
                            f"{prompt_text}\n\n"
                            f"Extract the data from this receipt PDF and use only the text below.\n"
                            f"Filename: {file_path.name}\n\n"
                            f"Receipt text:\n{extracted_text}"
                        ),
                    }
                ],
            }
        ],
    )

    raw_output = getattr(response, "output_text", "") or ""
    if not raw_output:
        raw_output = "".join(
            block.get("text", "")
            for item in getattr(response, "output", [])
            for block in item.get("content", [])
            if isinstance(block, dict)
        )

    if not raw_output:
        raise RuntimeError(f"No output returned for {file_path.name}")

    clean_json = clean_extracted_json(raw_output)
    parsed = json.loads(clean_json)
    if isinstance(parsed, dict):
        parsed = [parsed]
    if not isinstance(parsed, list):
        raise ValueError(f"Expected JSON array for {file_path.name}, got {type(parsed).__name__}")

    return [normalize_row(row, file_path.name) for row in parsed]


def parse_args():
    parser = argparse.ArgumentParser(description="Extract receipt rows from a PDF document pack.")
    parser.add_argument("--docs-dir", type=Path, default=DEFAULT_DOCS_DIR, help="Directory containing receipt PDFs")
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUTPUT_DIR, help="Directory to write the output JSON file")
    return parser.parse_args()


def main():
    args = parse_args()
    docs_dir = args.docs_dir.resolve()
    out_dir = args.out_dir.resolve()

    prompt_text = read_prompt_template()
    client = build_client()
    rows = []

    for receipt_file in get_receipt_files(docs_dir):
        extracted_rows = extract_receipt_row(client, receipt_file, prompt_text)
        rows.extend(extracted_rows)

    out_dir.mkdir(parents=True, exist_ok=True)
    output_path = out_dir / "receipts.json"
    output_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(f"Saved {len(rows)} extracted receipt rows to {output_path}")


if __name__ == "__main__":
    main()
